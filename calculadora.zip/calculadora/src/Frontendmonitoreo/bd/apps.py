from django.apps import AppConfig


class BdConfig(AppConfig):
    name = 'bd'
