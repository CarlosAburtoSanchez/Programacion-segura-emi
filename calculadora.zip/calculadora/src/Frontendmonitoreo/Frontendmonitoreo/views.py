from django.template import Template, Context
from django.shortcuts import render, redirect
from bd import models
from bd import decoradores
import Frontendmonitoreo.Backend as Backend #duda de este import

def login(request):
	t ='login.html'
	
	if request.method == 'GET':
		return render(request,t)
	elif request.method =='POST':
		if Backend.dejar_pasar_peticion_login(request):
			usuario = request.POST.get('usuario').strip()
			password = request.POST.get('password').strip()
			try:
				models.adminGlobal.objects.get(usuario=usuario, password=password)
				request.session['logueado'] = True
				return redirect('/login2/')
			except:
				return render(request, t, {'errores':'Error en el credeciales'})
		else:
			return render(request, t, {'errores':'No te pases de vrga me quieres hakiar'})

@decoradores.esta_logueado
def login2(request):
	t = 'login2.html'
	if request.method == 'GET':
		return render(request,t)
	elif request.method =='POST':
		if Backend.dejar_pasar_peticion_login(request):
			tokeen = request.POST.get('tokeen').strip()
			try:
				models.adminGlobal.objects.get(tokeen=tokeen)
				request.session['logueado'] = True
				return redirect('/login/')
			except:
				return render(request, t, {'errores':'Error en el token'})
		else:
			return render(request, t, {'errores':'No te pases de vrga me quieres hakiar'})
	
	return render(request,t)
def logout(request):
    request.session['logueado'] = False
    return redirect('/login/')

