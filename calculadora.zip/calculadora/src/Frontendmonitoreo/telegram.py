import requests
import sys


CHAT_ID = '639488039'
BOT_TOKEN = '1004427487:AAFrRGAYDiZ80Pzp5c-1RuQ1GxnFHnRGSPY'

def mandar_mensaje(mensaje):        
    send_text = 'https://api.telegram.org/bot%s/sendMessage?chat_id=%s&parse_mode=Markdown&text=%s' % (BOT_TOKEN, CHAT_ID, mensaje)
    response = requests.get(send_text)
    return response.json()

if __name__ == '__main__':
    mensaje = sys.argv[1]
    respuesta = mandar_mensaje(mensaje)
    print(respuesta)